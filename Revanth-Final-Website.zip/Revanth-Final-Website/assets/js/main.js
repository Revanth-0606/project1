document.addEventListener("DOMContentLoaded", () => {
  console.log("Website loaded and interactive!");
});
